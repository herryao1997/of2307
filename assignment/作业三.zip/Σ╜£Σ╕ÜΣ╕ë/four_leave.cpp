#include "picture.h"
#include <cmath>

int main () {
    Picture pic(800, 800);
    const double PI = 3.1415926;

    double theta = 0;
    double delta = 2 * PI / 1000;
    double radius = 0;
    double x = 0;
    double y = 0;


    // TODO: think about how to draw this picture
    for (int i = 0; i < 1000; ++i) {
        
        
    }

    pic.save("four_leave.png");

    return 0;
}